# -*- coding: utf-8 -*-
{
    'name': 'Purchase Custom Line',
    'version': '1.0',
    'category': 'Purchases',
    'description': "Purchase Custom Line add Initial unit Price and Support",
    'depends': ['purchase'],
    'data': [
        'views/purchase_custom_line.xml',
    ],
    'installable': True,
}
